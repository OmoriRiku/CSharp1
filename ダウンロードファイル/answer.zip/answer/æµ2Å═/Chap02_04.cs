﻿using System;

namespace Chap02
{
    class Program
    {
        static void Main(string[] args)
        {
            var str = "改行を示すエスケープシーケンスは、\\nです。";
            Console.WriteLine(str);
        }
    }
}
