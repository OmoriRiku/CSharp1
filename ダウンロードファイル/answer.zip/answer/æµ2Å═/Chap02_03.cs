﻿using System;

namespace Chap02
{
    class Program
    {
        static void Main(string[] args)
        {
            var kilometersPerHour = 54;
            var hour = 3;
            var kilometer = kilometersPerHour * hour;
            Console.WriteLine(kilometer);
        }
    }
}
