﻿using System;

namespace Chap02
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            name = "山田";
            Console.WriteLine("{0}さん、こんにちは", name);
        }
    }
}
