﻿using System;

namespace Chap02
{
    class Program
    {
        static void Main(string[] args)
        {
            var name = "近藤";
            var age = 19;
            Console.WriteLine("{0}さんは、{1}歳です", name, age);
        }
    }
}
