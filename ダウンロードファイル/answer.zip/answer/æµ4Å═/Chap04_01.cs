﻿using System;

namespace Chap04
{
    class Program
    {
        static void Main(string[] args)
        {
            var line = Console.ReadLine();
            if (line == "")
            { 
                Console.WriteLine("空文字列です");
            }
        }
    }
}
