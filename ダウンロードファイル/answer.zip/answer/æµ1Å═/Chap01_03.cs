﻿using System;

class Program
{
    // Mainメソッド
    static void Main()
    {

        Console.WriteLine("はじめまして。");
        Console.WriteLine("私はプログラミングが大好きです。");
    }
}
