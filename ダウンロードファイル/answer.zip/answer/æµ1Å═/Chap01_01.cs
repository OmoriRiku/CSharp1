﻿class Hello
{
    // Mainメソッド
    static void Main()
    {
        System.Console.WriteLine("はじめての、C#プログラミング");
    }
}
