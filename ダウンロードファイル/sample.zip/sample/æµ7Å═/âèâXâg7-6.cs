// ■リスト7-6：複数のインスタンスを生成する
var book1 = new Book  // 1つ目のBookインスタンスを生成
{
    Title = "吾輩は猫である",
    Author = "夏目漱石",
    Pages = 610,
    Rating = 4
};

var book2 = new Book  // 2つ目のBookインスタンスを生成
{
    Title = "人間失格",
    Author = "太宰治",
    Pages = 212,
    Rating = 5
};
