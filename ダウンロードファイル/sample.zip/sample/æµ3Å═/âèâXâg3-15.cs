// ■リスト3-15：+演算子による文字列と他の型の連結
var season = '夏';  // char型
var temperature = 39;  // int型
var str = "今年の" + season + "の最高気温は、" + temperature + "度でした。";
Console.WriteLine(str);
