// ■リスト3-17：挿入文字列を使った文字列の組み立て（1）
var season = '夏';
var temperature = 39;
var str = $"今年の{season}の最高気温は、{temperature}度でした。";
Console.WriteLine(str);
