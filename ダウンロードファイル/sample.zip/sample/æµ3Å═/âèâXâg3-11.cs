// ■リスト3-11：+演算子による文字列同士の連結（1）
var name = "渡辺";
var message = name + "さん、おはようございます。";
Console.WriteLine(message);
