// ■リスト3-14：+=演算子による文字列の連結
var message = "こんにちは、";
message += "今日は良い天気ですね。";  // message変数の後ろに文字列を追加する
Console.WriteLine(message);
