// ■リスト3-4：+単項演算子と-単項演算子
var x = +100;
var y = -5;
var a = +(x + y);
var b = -(x + y);
Console.WriteLine("a = {0}, b = {1}", a ,b);
