// ■リスト9-4：usingディレクティブを利用する
using MyApp.Map;  // MyApp.Map名前空間を利用する

namespace MyApp
{
    class Program
    {
        static void Main()
        {
            var mapLocation = new Location();  // 名前空間を指定しなくてもMyApp.Map.Locationクラスを利用できる
            ……
        }
    }
}
