// ■リスト9-29：新規に追加されたクラス
// よく利用される5つの名前空間がusingされている
using System;                      
using System.Collections.Generic;  
using System.Linq;                
using System.Text;                 
using System.Threading.Tasks;     

namespace MyApp
{
    class Book
    {
    }
}
