// ■リスト9-15：絶対値を求める（1）
var abs1 = Math.Abs(150);
var abs2 = Math.Abs(-320);
Console.WriteLine(abs1);
Console.WriteLine(abs2);
