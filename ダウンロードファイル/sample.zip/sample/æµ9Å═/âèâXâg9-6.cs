// ■リスト9-6：文字列の文字数を取得する
var str = "ようこそ、C#の世界へ";
var length = str.Length;  // Lengthプロパティで文字数を参照できる
Console.WriteLine($"{length}文字です");
