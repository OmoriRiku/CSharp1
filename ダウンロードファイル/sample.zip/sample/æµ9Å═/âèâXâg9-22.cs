// ■リスト9-22：今日の日付を取得する
var today = DateTime.Today;  // 今日の日付を取得する
Console.WriteLine("{0}年", today.Year);
Console.WriteLine("{0}月", today.Month);
Console.WriteLine("{0}日", today.Day);
Console.WriteLine("{0}時", today.Hour);
Console.WriteLine("{0}分", today.Minute);
Console.WriteLine("{0}秒", today.Second);
