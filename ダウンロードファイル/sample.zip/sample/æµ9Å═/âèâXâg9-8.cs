// ■リスト9-8：前後の空白文字を取り除く
var str = "  オブジェクト指向   ";
var str2 = str.Trim();  // 文字列の前後の空白を取り除く
Console.WriteLine($"[{str}]");
Console.WriteLine($"[{str2}]");
