// ■リスト6-7：foreach文で配列の各要素にアクセスする（2）
var numbers = new double[] { 10.5, 8.3, 4.5, 9.0 };
foreach (var num in numbers)  // numはdouble型
{
    Console.WriteLine(num);
}
