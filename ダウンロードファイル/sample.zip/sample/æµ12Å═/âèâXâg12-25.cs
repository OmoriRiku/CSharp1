// ■リスト12-25：Sumメソッドを使ったコード（1）
var nums = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
var sum = nums.Sum();  // 合計を求める
Console.WriteLine(sum);
