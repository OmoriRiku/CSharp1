// ■リスト12-5：リストの要素数を知る
var count = lines.Count;  // リストに格納されている要素の数を取得する
Console.WriteLine(count);
