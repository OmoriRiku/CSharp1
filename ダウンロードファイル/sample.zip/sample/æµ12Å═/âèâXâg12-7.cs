// ■リスト12-7：リストからすべての要素を削除する
lines.Clear();
Console.WriteLine($"要素数:{lines.Count}");
