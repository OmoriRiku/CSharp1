// ■リスト12-27：Maxメソッドを使ったコード（1）
var nums = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
var max = nums.Max();  // 最大値を求める
Console.WriteLine(max);
