// ■リスト11-5：列挙型を定義する（値を明示）
enum CardSuit
{
    Club = 0,
    Spade = 1,
    Heart = 2,
    Diamond = 3
}
