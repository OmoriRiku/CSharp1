// ■リスト10-18：オーバーロードしたコンストラクターの呼び出し
var person1 = new Person();

var person2 = new Person("勇太", "佐々木");
