// ■リスト2-1：変数の基本的な操作
 1  using System;
 2
 3  namespace MySample
 4  {
 5      class Program
 6      {
 7          static void Main(string[] args)
 8          {
 9              int age;                    // ageという名前で整数型の変数を用意する
10              age = 23;                   // age変数に23を入れる
11              Console.WriteLine(age);     // age変数の内容を表示する
12          }
13      }
14  }
