// ■リスト2-8：浮動小数点型（double）の変数
var squareRoot = 1.41421356;  // 小数点の付く数値はdouble型になる
var sideLength = 10.0;        // 同上
var diagonal = sideLength * squareRoot;
Console.WriteLine("対角線の長さ:{0}メートル", diagonal);
