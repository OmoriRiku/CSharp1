// ■リスト2-13：bool型の変数
bool exists = true;
var married = false;     // falseはbool型なので、marriedもbool型
