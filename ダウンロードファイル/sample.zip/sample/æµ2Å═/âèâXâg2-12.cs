// ■リスト2-12：文字型（char型）の変数
var alphabet = 'A';
var symbol = '*';
var kanji = '愛';
var kana = 'あ';
