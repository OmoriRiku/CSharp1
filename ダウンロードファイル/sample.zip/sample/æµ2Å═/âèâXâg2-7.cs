// ■リスト2-7：varを使った変数の初期化（キーボードからの入力を変数に代入）
Console.WriteLine("名前を入力してください。");
var name = Console.ReadLine();
Console.WriteLine("{0}さん、おはようございます。", name);
