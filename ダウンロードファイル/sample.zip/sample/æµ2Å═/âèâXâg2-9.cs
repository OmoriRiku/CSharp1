// ■リスト2-9：decimal型の変数
var price = 1280m;
var priceIncludingTax = price * 1.08m;
Console.WriteLine(priceIncludingTax);
