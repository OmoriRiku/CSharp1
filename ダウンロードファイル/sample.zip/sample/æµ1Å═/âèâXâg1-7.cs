// ■リスト1-7：完成したソースコード
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(100 + 5);  // この4行を追加
            Console.WriteLine(100 - 5);  // 同上
            Console.WriteLine(100 * 5);  // 同上
            Console.WriteLine(100 / 5);  // 同上
        }
    }
}
