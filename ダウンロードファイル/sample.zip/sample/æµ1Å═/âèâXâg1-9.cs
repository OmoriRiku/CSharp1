// ■リスト1-9：整えられているソースコード（リスト1-3再掲）
using System;

class Hello
{
    static void Main()
    {
         Console.WriteLine("ようこそ、C#の世界へ");
    }
}
