// ■リスト1-5：数値を扱う
using System;
class Program
{
    static void Main()
    {
        Console.WriteLine(100 + 5);  // 計算結果が出力される
        Console.WriteLine(100 - 5);  // 同上
        Console.WriteLine(100 * 5);  // 同上
        Console.WriteLine(100 / 5);  // 同上
    }
}
