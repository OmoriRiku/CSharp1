// ■リスト4-7：変数が範囲内かを条件OR演算子で判断するif文
var num = 15;
if (num % 3 == 0 || num % 5 == 0)
{
    Console.WriteLine("numは3か5で割り切れます");
}
