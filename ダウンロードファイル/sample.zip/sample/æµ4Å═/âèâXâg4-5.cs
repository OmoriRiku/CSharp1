// ■リスト4-5：if文の例（文字列の比較）
var lang = Console.ReadLine();
if (lang == "C#")  // == は「等しい」を意味する
{
    Console.WriteLine("langの値は「C#」です。");
}
if (lang != "Java")  // != は不等号を意味する
{
    Console.WriteLine("langの値は「Java」ではありません。");
}
