// ■リスト14-9：派生クラスのインスタンスを生成し、基底クラスの変数に代入する
VirtualPet pet1 = new FoodiePet("エイミー");  // 派生クラスのオブジェクトを基底クラスの変数に代入
VirtualPet pet2 = new CheerfulPet("クー");   // 同上
VirtualPet pet3 = new SleepyPet("ライアン");  // 同上
